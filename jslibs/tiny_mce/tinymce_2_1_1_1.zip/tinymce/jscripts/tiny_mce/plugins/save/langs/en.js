// UK lang variables

tinyMCE.addToLang('',{
save_desc : 'Save',
cancel_desc : 'Cancel all changes'
});
