Language packs are from version 2.0.5 removed from the core but can be downloadable from the TinyMCE website.
http://tinymce.moxiecode.com/download.php

The language pack codes are based on ISO-639-1
http://www.loc.gov/standards/iso639-2/englangn.html

Try using entires if possible. &aring; etc.
