tinyMCE.addI18n('da.paste_dlg',{
text_title:"Anvend CTRL+V p\u00E5 tastaturet for at inds\u00E6tte teksten.",
text_linebreaks:"Bevar linieskift",
word_title:"Anvend CTRL+V p\u00E5 tastaturet for at inds\u00E6tte teksten."
});