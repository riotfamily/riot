tinyMCE.addI18n('vi.paste_dlg',{
text_title:"S\u1EED d\u1EE5ng t\u1ED5 h\u1EE3p ph\u00EDm CTRL+V \u0111\u1EC3 d\u00E1n n\u1ED9i dung v\u00E0o khung b\u00EAn d\u01B0\u1EDBi.",
text_linebreaks:"Gi\u1EEF nguy\u00EAn nh\u1EEFng ch\u1ED7 xu\u1ED1ng h\u00E0ng",
word_title:"S\u1EED d\u1EE5ng t\u1ED5 h\u1EE3p ph\u00EDm CTRL+V \u0111\u1EC3 d\u00E1n n\u1ED9i dung v\u00E0o khung b\u00EAn d\u01B0\u1EDBi."
});