tinyMCE.addI18n('fi.paste_dlg',{
text_title:"Paina CTRL+V liitt\u00E4\u00E4ksesi teksti ikkunaan.",
text_linebreaks:"S\u00E4ilyt\u00E4 rivinvaihdot",
word_title:"Paina CTRL+V liitt\u00E4\u00E4ksesi teksti ikkunaan."
});