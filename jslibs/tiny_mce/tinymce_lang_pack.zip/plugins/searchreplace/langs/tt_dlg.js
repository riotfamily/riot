tinyMCE.addI18n('tt.searchreplace_dlg',{
searchnext_desc:"\u518D\u6B21\u641C\u5C0B",
notfound:"\u641C\u5C0B\u5DF2\u5B8C\u6210 ! \u627E\u4E0D\u5230\u4EFB\u4F55\u76EE\u6A19\u3002 ",
search_title:"\u641C\u5C0B",
replace_title:"\u641C\u5C0B/\u53D6\u4EE3",
allreplaced:"\u5DF2\u53D6\u4EE3\u6240\u6709\u5339\u914D\u7684\u5B57\u4E32.",
findwhat:"\u641C\u5C0B\u76EE\u6A19",
replacewith:"\u53D6\u4EE3\u7232",
direction:"\u65B9\u5411",
up:"\u5411\u4E0A",
down:"\u5411\u4E0B",
mcase:"\u5340\u5206\u5927\u5C0F\u5BEB",
findnext:"\u641C\u5C0B\u4E0B\u4E00\u500B",
replace:"\u53D6\u4EE3",
replaceall:"\u5168\u90E8\u53D6\u4EE3"
});