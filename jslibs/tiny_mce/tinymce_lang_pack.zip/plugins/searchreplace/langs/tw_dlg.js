tinyMCE.addI18n('tw.searchreplace_dlg',{
searchnext_desc:"\u7E7C\u7E8C\u67E5\u627E",
notfound:"\u67E5\u627E\u5B8C\u7562, \u6C92\u6709\u627E\u5230\u7B26\u5408\u7684\u5B57\u4E32.  ",
search_title:"\u67E5\u627E",
replace_title:"\u67E5\u627E/\u66FF\u63DB",
allreplaced:"\u6240\u6709\u7B26\u5408\u7684\u5B57\u4E32\u5747\u5DF2\u66FF\u63DB.  ",
findwhat:"\u67E5\u627E\u76EE\u6A19",
replacewith:"\u66FF\u63DB\u70BA",
direction:"\u65B9\u5411",
up:"\u5411\u4E0A",
down:"\u5411\u4E0B",
mcase:"\u5340\u5206\u5927\u5C0F\u5BEB",
findnext:"\u67E5\u627E\u4E0B\u4E00\u500B",
replace:"\u66FF\u63DB",
replaceall:"\u5168\u90E8\u66FF\u63DB"
});