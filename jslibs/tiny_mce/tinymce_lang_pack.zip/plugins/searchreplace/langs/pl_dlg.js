tinyMCE.addI18n('pl.searchreplace_dlg',{
searchnext_desc:"Znajd\u017A ponownie",
notfound:"Wyszukiwanie zako\u0144czone. Poszukiwany fragment nie zosta\u0142 znaleziony.",
search_title:"Znajd\u017A",
replace_title:"Znajd\u017A/Zamie\u0144",
allreplaced:"Wszystkie wyst\u0105pienia szukanego fragmentu zosta\u0142y zast\u0105pione.",
findwhat:"Znajd\u017A...",
replacewith:"Zamie\u0144 z...",
direction:"Kierunek",
up:"W g\u00F3r\u0119",
down:"W d\u00F3\u0142",
mcase:"Dopasuj case",
findnext:"Znajd\u017A nast\u0119pny",
replace:"Zamie\u0144",
replaceall:"Zamien wszystko"
});