tinyMCE.addI18n('ia.searchreplace_dlg',{
searchnext_desc:"\u518D\u6B21\u67E5\u627E",
notfound:"\u67E5\u627E\u5DF2\u5B8C\u6210 ! \u627E\u4E0D\u5230\u4EFB\u4F55\u76EE\u6807\u3002 ",
search_title:"\u67E5\u627E",
replace_title:"\u67E5\u627E/\u66FF\u6362",
allreplaced:"\u5DF2\u66FF\u6362\u6240\u6709\u5339\u914D\u7684\u5B57\u7B26\u4E32.",
findwhat:"\u67E5\u627E\u76EE\u6807",
replacewith:"\u66FF\u6362\u4E3A",
direction:"\u65B9\u5411",
up:"\u5411\u4E0A",
down:"\u5411\u4E0B",
mcase:"\u533A\u5206\u5927\u5C0F\u5199",
findnext:"\u67E5\u627E\u4E0B\u4E00\u4E2A",
replace:"\u66FF\u6362",
replaceall:"\u5168\u90E8\u66FF\u6362"
});