tinyMCE.addI18n('es.template_dlg',{
title:"Plantillas",
label:"Plantilla",
desc_label:"Descripci\u00F3n",
desc:"Insertar contenido de plantilla predefinida",
select:"Seleccionar plantilla",
preview:"Vista previa",
warning:"Cuidado: Actualizar una plantilla con otra puede causar p\u00E9rdida de datos.",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre",
months_short:"Ene,Feb,Mar,Abr,May,Jun,Jul,Ago,Sep,Oct,Nov,Dic",
day_long:"Domingo,Lunes,Martes,Mi\u00E9rcoles,Jueves,Viernes,S\u00E1bado,Domingo",
day_short:"Dom,Lun,Mar,Mie,Jue,Vie,Sab,Dom"
});