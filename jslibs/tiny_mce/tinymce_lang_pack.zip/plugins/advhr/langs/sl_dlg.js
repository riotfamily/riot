tinyMCE.addI18n('sl.advhr_dlg',{
width:"\u0160irina",
size:"Vi\u0161ina",
noshade:"Brez sen\u010Denja"
});