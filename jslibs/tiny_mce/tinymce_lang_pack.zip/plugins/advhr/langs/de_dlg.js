tinyMCE.addI18n('de.advhr_dlg',{
width:"Breite",
size:"H\u00F6he",
noshade:"Kein Schatten"
});