tinyMCE.addI18n('nb.advhr_dlg',{
width:"Bredde",
size:"St\u00F8rrelse",
noshade:"Ingen skygge"
});