tinyMCE.addI18n('sc.advhr_dlg',{
width:"\u5BBD",
size:"\u957F",
noshade:"\u65E0\u9634\u5F71"
});